clc;
clear;
close all; 

folder = 'F:\Final Project Code\Codes\Photos' ;
file = [dir(fullfile(folder,'*.jpg'))]; %gathers the name of the imageb

for k = 1:length(file)
    [~,baseFileName,~] = fileparts(file(k).name) ;
    ca{k} = baseFileName ;
end

[ca , sortOrder] = sortrows(ca') ;
file = file(sortOrder) ;

button = menu('Which gray image you want to use ?', ca);

if(button == 0)
    return ;
end

baseFileName = file(button).name ;
fullFileName = fullfile(folder,baseFileName) ;
disp(baseFileName);
disp(fullFileName) ;

if ~exist(fullFileName)
	% File doesn't exist -- didn't find it there.  Check the search path for it.
	fullFileNameOnSearchPath = baseFileName; % No path this time.
	if ~exist(fullFileNameOnSearchPath)
		% Still didn't find it.  Alert user.
		errorMessage = sprintf('Error: File not Found!');
 		uiwait(warndlg(errorMessage));
		return;
	end
end

[grayCoverImage,storedColourMap] = imread(fullFileName);
[~,~,numberOfColourChannels] = size(grayCoverImage) ;
disp(numberOfColourChannels);

if (numberOfColourChannels>1)
    grayCoverImage = grayCoverImage(:, :, 1);
elseif ~isempty(storedColorMap)
	grayCoverImage = ind2rgb(grayCoverImage, storedColorMap);
	grayCoverImage = uint8(255 * mat2gray(rgb2gray(grayCoverImage)));
end

[~,~, numberOfColorChannels] = size(grayCoverImage);

figure('units','normalized','outerposition',[0 0 1 1]); ;
subplot(1, 2, 1);
imshow(grayCoverImage, []);
axis on;
caption = sprintf('The Original Grayscale Image\nThe "Cover" Image.');
title(caption) ;

hiddenString = 'Please enter a string like this.' ;
defaultValue = hiddenString ;
titleBar = 'Enter the string you want to hide.';
userPrompt = 'Enter the string you want to hide';
caUserInput = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 110], {num2str(defaultValue)});

if isempty(caUserInput)
    errorMessage = sprintf('Error: No input!');
 	uiwait(warndlg(errorMessage));
    return ;
end

whos caUserInput;
hiddenString = cell2mat(caUserInput); 
whos hiddenString ;




%==========================================================================
%caesar code encryption
defaultValue = 1;
titleBar = 'Enter the key to convert to caesar code.';
userPrompt = 'Enter the number key to shift(From 0 to 26)';
caUserInput = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 15], {num2str(defaultValue)});
if isempty(caUserInput)
    errorMessage = sprintf('Error: No input!');
 	uiwait(warndlg(errorMessage));
    return ;
end

caUserInput_e = round(str2double(cell2mat(caUserInput)));
if(caUserInput_e>26 || caUserInput_e<0)
    errorMessage = sprintf('You did not put a number between 0 to 26');
 	uiwait(warndlg(errorMessage));
    return ;
end

% disp(caUserInput) ;

hiddenString = caesar_E1(hiddenString,caUserInput_e) ;
%==========================================================================




%==============================================================================================================
%inputting password
password = '' ;
defaultValue = password ;
titleBar = 'Password';
userPrompt = 'Enter a four character password';
caUserInput1 = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 100], {num2str(defaultValue)}); %takes password



caUserInput1 = cell2mat(caUserInput1) ;
if(length(caUserInput1)~= 4) 
    uiwait(warndlg('You did not enter a 4 character message!'));
    return ;
end

hiddenString = [caUserInput1 hiddenString];
%==============================================================================================================

defaultValue = 1;
titleBar = 'Enter the bit plane.';
userPrompt = 'Enter the bit plane you want to use (1 through 8)';
caUserInput = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 15], {num2str(defaultValue)});
if isempty(caUserInput)
    errorMessage = sprintf('Error: No input!');
 	uiwait(warndlg(errorMessage));
    return ;
end

integerValue = round(str2double(cell2mat(caUserInput)));

if isnan(integerValue)
    integerValue = defaultValue;
    message = sprintf('I said it had to be an integer.\nI will use %d and continue.', integerValue);
    uiwait(warndlg(message));
end
bitToSet = integerValue; 
if bitToSet < 1
	bitToSet = 1;
elseif bitToSet > 8
	bitToSet = 8;
end



hiddenString = sprintf('%4.4d%s', length(hiddenString), hiddenString);
asciiValues = hiddenString - 0 ; 
stringLength = length(asciiValues);

numPixelsInImage = numel(grayCoverImage);
bitsPerLetter = 7;
numPixelsNeededForString = stringLength * bitsPerLetter;


if numPixelsNeededForString > numPixelsInImage
	warningMessage = sprintf('Your message is %d characters long.\nThis will require %d pixels,\nhowever your image has only %d pixels.\nI will use just the first %d characters.',...
		stringLength, numPixelsNeededForString, numPixelsInImage, numPixelsInImage);
	uiwait(warndlg(warningMessage));
	asciiValues = asciiValues(1:floor(numPixelsInImage/bitsPerLetter));
	stringLength = length(asciiValues);	
	numPixelsNeededForString = stringLength * bitsPerLetter;
else
	message = sprintf('Your message is %d characters long.\nThis will require %d * %d = %d pixels,\nYour image has %d pixels so it will fit.',...
		stringLength, stringLength, bitsPerLetter, numPixelsNeededForString, numPixelsInImage);
	fprintf('%s\n', message);
	uiwait(helpdlg(message));
end
binaryAsciiString = dec2bin(asciiValues)' ;
whos binaryAsciiString ;
binaryAsciiString = binaryAsciiString(:)' ;

stegoImage = grayCoverImage;
stegoImage(1:numPixelsNeededForString) = bitset(stegoImage(1:numPixelsNeededForString), bitToSet, 0);
oneIndexes = find(binaryAsciiString == '1'); 

stegoImage(oneIndexes) = bitset(stegoImage(oneIndexes), bitToSet, 1);


%==========================================================================
hiddenString = '' ;
defaultValue = hiddenString ;
titleBar = 'Password';
userPrompt = 'Re-enter the password';
caUserInput2 = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 100], {num2str(defaultValue)}); %takes password

caUserInput2 = cell2mat(caUserInput2) ;
if(caUserInput2~=caUserInput1)
    message = sprintf('The password is incorrect!');
    uiwait(warndlg(message));
    return ;
end
%==========================================================================

subplot(1, 2, 2);
imshow(stegoImage, []);
axis on;
caption = sprintf('Image with your string hidden\nin the upper left column.');
if bitToSet < 5
	caption = sprintf('%s\n(You will not be able to notice it.)', caption);
end
title(caption);

numPixelsNeededForString = 4 * bitsPerLetter;
retrievedBits = bitget(stegoImage(1:numPixelsNeededForString), bitToSet)
letterCount = 1;

for k = 1 : bitsPerLetter : numPixelsNeededForString
	% Get the binary bits for this one character.
	thisString = retrievedBits(k:(k+bitsPerLetter-1));
	% Turn it from a binary string into an ASCII number (integer) and then finally into a character/letter.
	thisChar = char(bin2dec(num2str(thisString)));
	% Store this letter as we build up the recovered string.
	recoveredString(letterCount) = thisChar;
	letterCount = letterCount + 1;
end

stringLength = str2double(recoveredString) + 4;
numPixelsNeededForString = stringLength * bitsPerLetter;
retrievedBits = bitget(stegoImage(1:numPixelsNeededForString), bitToSet); 

retrievedAsciiTable = reshape(retrievedBits, [bitsPerLetter, numPixelsNeededForString/bitsPerLetter]);
letterCount = 1;
nextPixel = 4 * bitsPerLetter + 1;

for k = nextPixel : bitsPerLetter : numPixelsNeededForString
	% Get the binary bits for this one character.
	thisString = retrievedBits(k:(k+bitsPerLetter-1));
	% Turn it from a binary string into an ASCII number (integer) and then finally into a character/letter.
	thisChar = char(bin2dec(num2str(thisString)));
	% Store this letter as we build up the recovered string.
	recoveredString(letterCount) = thisChar;
	letterCount = letterCount + 1;
end

%=============================================================
recoveredString = recoveredString(5:end) ;
recoveredString
%=============================================================

%==========================================================================
%decrypting from caesar code
defaultValue = 1;
titleBar = 'Enter the key to decrypt caesar code.';
userPrompt = 'Enter the previous number key to shift';
caUserInput = inputdlg(userPrompt, titleBar, [1, length(userPrompt) + 15], {num2str(defaultValue)});
if isempty(caUserInput)
    errorMessage = sprintf('Error: No input!');
 	uiwait(warndlg(errorMessage));
    return ;
end

caUserInput_d = round(str2double(cell2mat(caUserInput)));

recoveredString = caesar_D1(recoveredString,caUserInput_d);
%==========================================================================

if(caUserInput_d~=caUserInput_e)
    errorMessage = sprintf('The shift key doesnot match\nThe output string will be irrelevant');
 	uiwait(warndlg(errorMessage));
end


message = sprintf('The recovered string = \n%s\n', recoveredString);
fprintf('%s\n', message);
uiwait(helpdlg(message));
