function C=caesar_D1(P,k)

% k=key (can be 0 to 26); k=0 mean No encryption

%===============================================
if k>26
    error('Key must be in rang from 1 to 26')
end

C = double(P);
l = find(C>96 & C<123);
C(l) = C(l) - k ;
% if(C(l)<97)
%     C(l) = C(l)+26 ; 
% end

for i = 1:length(l)
    if(C(l(i))<97)
        C(l(i)) = C(l(i))+ 26 ;
    end
end

l = find(C>64 & C<91);
C(l) = C(l) - k ;
% if(C(l)<65)
%     C(l) = C(l)-26 ;   
% end

for i = 1:length(l)
    if(C(l(i))<65)
        C(l(i)) = C(l(i))+ 26 ;
    end
end



C = char(C);
end