function varargout = steganographyGUI(varargin)
% STEGANOGRAPHYGUI MATLAB code for steganographyGUI.fig
%      STEGANOGRAPHYGUI, by itself, creates a new STEGANOGRAPHYGUI or raises the existing
%      singleton*.
%
%      H = STEGANOGRAPHYGUI returns the handle to a new STEGANOGRAPHYGUI or the handle to
%      the existing singleton*.
%
%      STEGANOGRAPHYGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in STEGANOGRAPHYGUI.M with the given input arguments.
%
%      STEGANOGRAPHYGUI('Property','Value',...) creates a new STEGANOGRAPHYGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before steganographyGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to steganographyGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".

%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help steganographyGUI

% Last Modified by GUIDE v2.5 21-Feb-2022 23:04:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @steganographyGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @steganographyGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before steganographyGUI is made visible.
function steganographyGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no outputtext args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to steganographyGUI (see VARARGIN)

% Choose default command line outputtext for steganographyGUI
handles.outputtext = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes steganographyGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = steganographyGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning outputtext args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line outputtext from handles structure
varargout{1} = handles.outputtext;



function confirmation_Callback(hObject, eventdata, handles)
% hObject    handle to confirmation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of confirmation as text
%        str2double(get(hObject,'String')) returns contents of confirmation as a double


% --- Executes during object creation, after setting all properties.
function confirmation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to confirmation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function retype_Callback(hObject, eventdata, handles)
% hObject    handle to retype (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of retype as text
%        str2double(get(hObject,'String')) returns contents of retype as a double


% --- Executes during object creation, after setting all properties.
function retype_CreateFcn(hObject, eventdata, handles)
% hObject    handle to retype (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function outputtext_Callback(hObject, eventdata, handles)
% hObject    handle to outputtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of outputtext as text
%        str2double(get(hObject,'String')) returns contents of outputtext as a double


% --- Executes during object creation, after setting all properties.
function outputtext_CreateFcn(hObject, eventdata, handles)
% hObject    handle to outputtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in showimage.
function showimage_Callback(hObject, eventdata, handles)
% hObject    handle to showimage (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global pass ;
    global stegoImage;
    global hidden_string;
    global recheck;
    global bit;
    global check_bit_plane;

    recheck =  (char(get(handles.confirmation,'String')));
    check_bit_plane = str2double(char(get(handles.bitconfirm,'String')));
    if (pass == recheck)
        if (check_bit_plane == bit)
            axes(handles.axes2);
            imshow(stegoImage);
            encrypttext = handles.recoveredString; %hidden_string(9:end);
            set(handles.encryptshow,'String', encrypttext);
        else
            alarttext = 'Wrong Bit Plane. Try Again';
            set(handles.encryptshow,'String', alarttext);    
        end
    else
        if (check_bit_plane == bit)
            alarttext = 'Wrong Password. Try Again';
            set(handles.encryptshow,'String', alarttext);
        else
            alarttext = 'Wrong Password And Bit Plane. Try Again';
            set(handles.encryptshow,'String', alarttext);
        end
    end



% --- Executes on button press in showtext.
function showtext_Callback(hObject, eventdata, handles)
% hObject    handle to showtext (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global hidden_string;
    global caesar;
    global recheck;
    global pass;
    global bit;
    global check_bit_plane;
    global caesar_eff;

    check_caesar = str2double(char(get(handles.retype,'String')));
    copy = handles.recoveredString;

    if(check_caesar == caesar)
        if(pass == recheck)
            if (bit == check_bit_plane)
                copy = caesar_D1(copy, caesar_eff);
                passed_text = copy;
                set(handles.output_text,'String', passed_text);
                guidata(hObject,handles);
            else
                passed_text = 'Please,Enter Correct Bit Plane First';
                set(handles.output_text,'String', passed_text);
            end

        else
            if (bit == check_bit_plane)
                passed_text = 'Please,Enter Correct Password First';
                set(handles.output_text,'String', passed_text);
            else
                passed_text = 'Please,Enter Correct Password & Bit Plane First';
                set(handles.output_text,'String', passed_text);
            end
        end
    else
        passed_text = 'Wrong Caesar Code';
        set(handles.output_text,'String', passed_text);
    end

% --- Executes on button press in upload.
function upload_Callback(hObject, eventdata, handles)
% hObject    handle to upload (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global A;
    global grayCoverImage;
    [filename, pathname] = uigetfile('*.*', 'Pick an Image');
    filename=fullfile(pathname,filename);
    [grayCoverImage,storedColourMap] = imread(filename);
    [~,~,numberOfColourChannels] = size(grayCoverImage) ;
            
    if (numberOfColourChannels>1)
        grayCoverImage = grayCoverImage(:, :, 1);
    elseif ~isempty(storedColorMap)
        grayCoverImage = ind2rgb(grayCoverImage, storedColorMap);
        grayCoverImage = uint8(255 * mat2gray(rgb2gray(grayCoverImage)));
    end

    [~,~, numberOfColorChannels] = size(grayCoverImage);

    A = grayCoverImage;
    axes(handles.axes3);
    imshow(A);


function textinput_Callback(hObject, eventdata, handles)
% hObject    handle to textinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of textinput as text
%        str2double(get(hObject,'String')) returns contents of textinput as a double


% --- Executes during object creation, after setting all properties.
function textinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to textinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function caesarinput_Callback(hObject, eventdata, handles)
% hObject    handle to caesarinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of caesarinput as text
%        str2double(get(hObject,'String')) returns contents of caesarinput as a double


% --- Executes during object creation, after setting all properties.
function caesarinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to caesarinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function password_Callback(hObject, eventdata, handles)
% hObject    handle to password (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of password as text
%        str2double(get(hObject,'String')) returns contents of password as a double


% --- Executes during object creation, after setting all properties.
function password_CreateFcn(hObject, eventdata, handles)
% hObject    handle to password (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function bit_Callback(hObject, eventdata, handles)
% hObject    handle to bit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bit as text
%        str2double(get(hObject,'String')) returns contents of bit as a double


% --- Executes during object creation, after setting all properties.
function bit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    global pass;
    global hidden_string;
    global caesar;
    global grayCoverImage;
    global stegoImage;
    global bit;
    global caesar_eff; 

    % text input
    hidden_string = char(get(handles.textinput,'String'));

    % caesar input
    caesar = str2double(char(get(handles.caesarinput,'String')));
        if (caesar<=1)
            caesar_eff = 1;
        elseif (caesar>1 && caesar<25)
            caesar_eff = caesar;
        elseif (caesar>=25)
            caesar_eff = 25;
        end


    % password input
    pass =  (char(get(handles.password,'String')));
    
    hidden_string = [pass,hidden_string];
    hidden_string = caesar_E1(hidden_string,caesar_eff);

    % bit plane input
    bit = str2double(char(get(handles.bit,'String')));
    if (bit<1)
        bit_eff = 1;
    elseif (bit>=1 && bit<=8)
        bit_eff = bit;
    elseif (bit>8)
        bit_eff = 8;
    end
    integerValue = round(bit_eff);
    bitToSet = integerValue;

    % finding ascii value of pixel
    hidden_string = sprintf('%4.4d%s', length(hidden_string), hidden_string);
    asciiValues = hidden_string - 0 ; 
    stringLength = length(asciiValues);

    numPixelsInImage = numel(grayCoverImage);
    bitsPerLetter = 7;
    numPixelsNeededForString = stringLength * bitsPerLetter;

    binaryAsciiString = dec2bin(asciiValues)' ;
    whos binaryAsciiString ;
    binaryAsciiString = binaryAsciiString(:)' ;

    stegoImage = grayCoverImage;
    bitToSet;
    stegoImage(1:numPixelsNeededForString) = bitset(stegoImage(1:numPixelsNeededForString), bitToSet, 0);
    oneIndexes = find(binaryAsciiString == '1'); 

    stegoImage(oneIndexes) = bitset(stegoImage(oneIndexes), bitToSet, 1);

    % change
    numPixelsNeededForString = 4 * bitsPerLetter;
    retrievedBits = bitget(stegoImage(1:numPixelsNeededForString), bitToSet);
    letterCount = 1;

    for k = 1 : bitsPerLetter : numPixelsNeededForString
	    % Get the binary bits for this one character.
	    thisString = retrievedBits(k:(k+bitsPerLetter-1));
	    % Turn it from a binary string into an ASCII number (integer) and then finally into a character/letter.
	    thisChar = char(bin2dec(num2str(thisString)));
	    % Store this letter as we build up the recovered string.
	    recoveredString(letterCount) = thisChar;
	    letterCount = letterCount + 1;
    end
   
    stringLength = str2double(recoveredString) + 4;
    numPixelsNeededForString = stringLength * bitsPerLetter;
    retrievedBits = bitget(stegoImage(1:numPixelsNeededForString), bitToSet); 

    retrievedAsciiTable = reshape(retrievedBits, [bitsPerLetter, numPixelsNeededForString/bitsPerLetter]);
    letterCount = 1;
    nextPixel = 4 * bitsPerLetter + 1;

    for k = nextPixel : bitsPerLetter : numPixelsNeededForString
	    % Get the binary bits for this one character.
	    thisString = retrievedBits(k:(k+bitsPerLetter-1));
	    % Turn it from a binary string into an ASCII number (integer) and then finally into a character/letter.
	    thisChar = char(bin2dec(num2str(thisString)));
	    % Store this letter as we build up the recovered string.
	    recoveredString(letterCount) = thisChar;
	    letterCount = letterCount + 1;
    end

    recoveredString = recoveredString(5:end);
   
    handles.recoveredString = recoveredString;
    guidata(hObject, handles);


function output_text_Callback(hObject, eventdata, handles)
% hObject    handle to output_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of output_text as text
%        str2double(get(hObject,'String')) returns contents of output_text as a double


% --- Executes during object creation, after setting all properties.
function output_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to output_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function encryptshow_Callback(hObject, eventdata, handles)
% hObject    handle to encryptshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of encryptshow as text
%        str2double(get(hObject,'String')) returns contents of encryptshow as a double


% --- Executes during object creation, after setting all properties.
function encryptshow_CreateFcn(hObject, eventdata, handles)
% hObject    handle to encryptshow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes1
imshow('..\Cover Image\preview.jpg')



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function axes4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
imshow('..\Cover Image\logo.png')

% Hint: place code in OpeningFcn to populate axes4


% --------------------------------------------------------------------
function uipushtool5_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function bitconfirm_Callback(hObject, eventdata, handles)
% hObject    handle to bitconfirm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of bitconfirm as text
%        str2double(get(hObject,'String')) returns contents of bitconfirm as a double


% --- Executes during object creation, after setting all properties.
function bitconfirm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to bitconfirm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object deletion, before destroying properties.
function axes1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to axes1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function axes4_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
